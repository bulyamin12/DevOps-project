
import os
import requests
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# URL ของ Ollama ใน Docker
OLLAMA_URL = "http://127.0.0.1:11434/api/chat"

# โมเดล AI ที่อนุญาตให้ใช้งาน
AVAILABLE_MODELS = [
    "qwen2.5-coder:1.5b",
    "llama3.2:3b"
]

# โมเดลเริ่มต้น
MODEL_NAME = os.getenv("OLLAMA_MODEL", "llama3.2:3b")


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    # รับข้อมูลจากหน้าเว็บ
    data = request.get_json(silent=True) or {}

    message = data.get("message", "").strip()
    history = data.get("history", [])

    # ตรวจสอบคำถาม
    if not message:
        return jsonify({"error": "กรุณาพิมพ์คำถามก่อน"}), 400

    # ตรวจสอบโมเดลที่เลือก
    selected_model = data.get("model", MODEL_NAME)

    if selected_model not in AVAILABLE_MODELS:
        return jsonify({"error": "ไม่รองรับโมเดลนี้"}), 400

    # เตรียมประวัติการสนทนา
    messages = []

    if isinstance(history, list):
        for item in history[-10:]:
            if (
                isinstance(item, dict)
                and item.get("role") in ("user", "assistant")
                and isinstance(item.get("content"), str)
            ):
                messages.append({
                    "role": item["role"],
                    "content": item["content"][:4000]
                })

    # เพิ่มคำถามปัจจุบัน
    messages.append({
        "role": "user",
        "content": message
    })

    # ข้อมูลที่จะส่งไปยัง Ollama
    payload = {
        "model": selected_model,
        "messages": messages,
        "stream": False
    }

    try:
        response = requests.post(
            OLLAMA_URL,
            json=payload,
            timeout=(5, 300)
        )

        response.raise_for_status()
        result = response.json()

        answer = result.get("message", {}).get("content", "")

        if not answer:
            return jsonify({
                "error": "AI ไม่ได้ส่งข้อความตอบกลับ"
            }), 502

        return jsonify({"answer": answer})

    except requests.exceptions.ConnectionError:
        return jsonify({
            "error": "เชื่อมต่อ Ollama ไม่ได้ กรุณาตรวจสอบ Docker และพอร์ต 11434"
        }), 503

    except requests.exceptions.Timeout:
        return jsonify({
            "error": "AI ใช้เวลาตอบนานเกินไป กรุณาลองใหม่"
        }), 504

    except requests.exceptions.HTTPError as e:
        detail = (
            e.response.text[:500]
            if e.response is not None
            else str(e)
        )

        return jsonify({
            "error": f"Ollama API Error: {detail}"
        }), 502

    except (ValueError, KeyError):
        return jsonify({
            "error": "ข้อมูลตอบกลับจาก Ollama ไม่ถูกต้อง"
        }), 502


if __name__ == "__main__":
    app.run(
        host="127.0.0.1",
        port=5000,
        debug=True
    )
