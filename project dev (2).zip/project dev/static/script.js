
const chatBox = document.getElementById("chatBox");
const chatForm = document.getElementById("chatForm");
const messageInput = document.getElementById("messageInput");
const sendBtn = document.getElementById("sendBtn");
const clearBtn = document.getElementById("clearBtn");
const statusBox = document.getElementById("status");
const modelSelect = document.getElementById("modelSelect");

let history = [];

// แสดงข้อความในหน้าแชต
function addMessage(role, content) {
    const welcome = chatBox.querySelector(".welcome");

    if (welcome) {
        welcome.remove();
    }

    const message = document.createElement("div");
    message.className = `message ${role}`;

    const sender = document.createElement("div");
    sender.className = "sender";
    sender.textContent = role === "user" ? "คุณ" : "Local AI";

    const bubble = document.createElement("div");
    bubble.className = "bubble";

    // ป้องกันข้อความถูกตีความเป็น HTML
    bubble.textContent = content;

    message.append(sender, bubble);
    chatBox.appendChild(message);

    chatBox.scrollTop = chatBox.scrollHeight;
}

// ส่งคำถามไปยัง Python Flask และ Ollama
chatForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const message = messageInput.value.trim();

    if (!message || sendBtn.disabled) {
        return;
    }

    addMessage("user", message);

    messageInput.value = "";
    sendBtn.disabled = true;
    statusBox.textContent = "AI กำลังคิดคำตอบ...";

    try {
        const response = await fetch("/chat", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                message: message,
                history: history,
                model: modelSelect.value
            })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || "เกิดข้อผิดพลาด");
        }

        // แสดงคำตอบจาก AI
        addMessage("assistant", data.answer);

        // บันทึกประวัติการสนทนา
        history.push(
            { role: "user", content: message },
            { role: "assistant", content: data.answer }
        );

        // เก็บประวัติไว้ไม่เกิน 10 ข้อความ
        history = history.slice(-10);

        statusBox.textContent = "";

    } catch (error) {
        addMessage(
            "assistant",
            "ไม่สามารถรับคำตอบได้: " + error.message
        );

        statusBox.textContent =
            "กรุณาตรวจสอบ Flask, Docker และ Ollama";
    } finally {
        sendBtn.disabled = false;
        messageInput.focus();
    }
});

// ล้างประวัติการสนทนา
clearBtn.addEventListener("click", () => {
    history = [];
    chatBox.replaceChildren();

    const welcome = document.createElement("div");
    welcome.className = "welcome";

    const icon = document.createElement("div");
    icon.className = "welcome-icon";
    icon.textContent = "✦";

    const title = document.createElement("h2");
    title.textContent = "เริ่มการสนทนาใหม่";

    const description = document.createElement("p");
    description.textContent = "พิมพ์คำถามของคุณได้เลย";

    welcome.append(icon, title, description);
    chatBox.appendChild(welcome);

    statusBox.textContent = "";
    messageInput.focus();
});
