
from crewai import Agent, Task, Crew, Process, LLM

MODELS = {
    "1": {
        "name": "Llama 3.2 3B Chat",
        "model": "ollama/llama3.2:3b",
    },
    "2": {
        "name": "Qwen Coder Local",
        "model": "ollama/qwen2.5-coder:1.5b",
    },
}


def ask_ai(question: str, model_name: str) -> str:
    llm = LLM(
        model=model_name,
        base_url="http://127.0.0.1:11434",
        temperature=0.5,
    )

    assistant = Agent(
        role="General AI Assistant and Coding Helper",
        goal="ตอบคำถามทั่วไปและช่วยเขียนโค้ดให้ตรงกับสิ่งที่ผู้ใช้ต้องการ",
        backstory=(
            "คุณเป็นผู้ช่วย AI ที่ตอบภาษาไทยและภาษาอังกฤษได้ "
            "ตอบคำถามทั่วไป อธิบายเรื่องต่าง ๆ และช่วยเขียนหรือแก้ไขโค้ด "
            "ตอบเป็นข้อความธรรมดาที่เข้าใจง่าย ไม่ส่ง JSON โดยไม่จำเป็น "
            "หากไม่ทราบคำตอบ ให้บอกตรง ๆ"
        ),
        llm=llm,
        allow_delegation=False,
        verbose=False,
    )

    task = Task(
        description=(
            "ตอบคำถามของผู้ใช้โดยตรง ใช้ภาษาตามคำถาม "
            "อธิบายให้เข้าใจง่าย หากเป็นคำถามเกี่ยวกับโค้ด "
            "ให้ยกตัวอย่างโค้ดเมื่อเหมาะสม\n\n"
            "คำถามของผู้ใช้: {question}"
        ),
        expected_output="คำตอบที่เป็นธรรมชาติ ตรงคำถาม และอ่านเข้าใจง่าย",
        agent=assistant,
    )

    crew = Crew(
        agents=[assistant],
        tasks=[task],
        process=Process.sequential,
        verbose=False,
    )

    result = crew.kickoff(inputs={"question": question})
    return str(result)


def main():
    print("=== Local AI Chat: CrewAI + Ollama ===")
    print("1. Llama 3.2 3B Chat")
    print("2. Qwen Coder Local")

    choice = input("เลือกโมเดล (1/2): ").strip()
    selected = MODELS.get(choice)

    if selected is None:
        print("เลือกไม่ถูกต้อง กรุณาเลือก 1 หรือ 2")
        return

    print(f"\nโมเดลที่เลือก: {selected['name']}")
    print("พิมพ์ exit เพื่อออกจากโปรแกรม\n")

    while True:
        try:
            question = input("คุณ: ").strip()

            if question.lower() in ("exit", "quit"):
                print("ปิดโปรแกรมแล้ว")
                break

            if not question:
                continue

            print("AI กำลังคิด...")
            answer = ask_ai(question, selected["model"])
            print(f"\nAI: {answer}\n")

        except KeyboardInterrupt:
            print("\nปิดโปรแกรมแล้ว")
            break
        except Exception as error:
            print(f"\nเกิดข้อผิดพลาด: {error}\n")
            print("ตรวจสอบ Docker, Ollama และชื่อโมเดล แล้วลองใหม่")


if __name__ == "__main__":
    main()
